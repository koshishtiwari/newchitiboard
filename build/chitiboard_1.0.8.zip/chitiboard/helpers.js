/*
// custom helper to use in .hbs files

let themeHelpers = {
    nameofHelper: function(argsinHelper) {
        let artToUse = argsinHelper;
    },

    anotherHelper: function(arg1, arg2) {
      return anotherHelper = {first:arg1, second:arg2}
    }
};

*/



// export the themeHelpers
module.exports = themeHelpers;